﻿//Referenced github rodrio13/MonteCarlo

using System;

namespace MonteCarlo
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Monte-Carlo Method");

			//for loop to pass 4 numbers: 10, 100, 1000, 10000.
			for (int i = 0; i < 4; i++)
			{
				Console.WriteLine("\nInput number of iterations");
				int Input = int.Parse(Console.ReadLine());
				Console.WriteLine("My estimated PI is ");
				double Diff = Math.Abs(RandomNumber(Input) / Math.PI);
				Console.WriteLine($"The diffrence between values is: {Diff}");
			}

		}

		public struct Pythagoreamtheorem 
		{
			double x, y;

			public Pythagoreamtheorem(double X, double Y) 
			{
				x = X;
				y = Y;
			}

			public Pythagoreamtheorem(Random R) 
			{
				x = R.NextDouble();
				y = R.NextDouble();
			}

			public double Hypotenuse() => Math.Sqrt((x * x) + (y * y));
		}
		public static double RandomNumber(int Number) 
		{
			Pythagoreamtheorem[] points = new Pythagoreamtheorem[Number];
			int Counter = 0;
			Random R = new Random();
			for (int i = 0; i < points.Length; i++) 
			{
				points[i] = new Pythagoreamtheorem(R);
				//points[i] = new Pythagoreamtheorem(R.Next(), R.Next());
				if (points[i].Hypotenuse() <= 1.0) 
				{
					Counter++;
				}
			}
			double Pi = ((double)Counter / points.Length) * 4;
			Console.WriteLine(Pi);
			Console.WriteLine($"PI is {Math.PI}");
			return Pi;
		}
	}
}
// 1. Why do we multiply the value from step 5 above by 4?
//    a. By multiplying by four your Pi approximate it better.

// 2. What do you observe in the output when running your program with parameters of increasing size?
//    a. The larger iterations made the estimate of PI became closer to the actual value of PI.

// 3. If you run the program multiple times with the same parameter, does the output remain the same? Why or why not?
//    a. No, it won't because of the random numbers used.

// 4. Find a parameter that requires multiple seconds of run time.What is that parameter? How accurate is the estimated value of?
//    a. When I input +1000000 the difference between my estimated PI and Math.PI is smaller.

// 5. Research one other use of Monte-Carlo methods. Record it in your exercise submission and be prepared to discuss it in class.
//    a. Monte Carlo simulations are used to model the probability of different outcomes in a process that cannot easily be predicted due to the intervention of random variables. 
//       It is a technique used to understand the impact of risk and uncertainty in prediction and forecasting models.